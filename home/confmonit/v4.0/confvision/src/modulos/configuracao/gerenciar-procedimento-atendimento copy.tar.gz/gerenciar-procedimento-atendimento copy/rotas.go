package gerenciarProcedimentoAtendimento

/*
var RotasGerenciarProcedimentoAtendimento = []auxiliar.Rota{
	{
		URI:    "/carregar-gerenciar-procedimento-atendimento",
		Metodo: http.MethodGet,
		Funcao: CarregarGerenciarProcedimentoAtentendimento,
		Aberto: false,
	},
	{
		URI:    "/procedimento-inserir",
		Metodo: http.MethodPost,
		Funcao: ProcedimentoInserir,
		Aberto: false,
	},
	{
		URI:    "/procedimento-carregar-tabela/{idFranqueado}",
		Metodo: http.MethodGet,
		Funcao: ProcedimentoCarregarTabela,
		Aberto: false,
	},
	{
		URI:    "/procedimento-habilitar/{id}/{status}",
		Metodo: http.MethodGet,
		Funcao: ProcedimentoHabilitar,
		Aberto: false,
	},
	{
		URI:    "/procedimento-inserir",
		Metodo: http.MethodPost,
		Funcao: ProcedimentoInserir,
		Aberto: false,
	},
	{
		URI:    "/procedimento-buscar/{id}",
		Metodo: http.MethodGet,
		Funcao: ProcedimentoBuscar,
		Aberto: false,
	},
	{
		URI:    "/procedimento-alterar",
		Metodo: http.MethodPut,
		Funcao: ProcedimentoAlterar,
		Aberto: false,
	},
	{
		URI:    "/procedimento-deletar",
		Metodo: http.MethodDelete,
		Funcao: ProcedimentoDeletar,
		Aberto: false,
	},
}
*/
