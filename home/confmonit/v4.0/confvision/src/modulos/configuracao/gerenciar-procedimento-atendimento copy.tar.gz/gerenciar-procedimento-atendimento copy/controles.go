package gerenciarProcedimentoAtendimento

import (
	"Web-Franqueado/src/auxiliar"
	"Web-Franqueado/src/config"
	"Web-Franqueado/src/seguranca"
	"bytes"
	"fmt"
	"io"
	"net/http"

	"github.com/gorilla/mux"
)

func CarregarGerenciarProcedimentoAtentendimento(w http.ResponseWriter, r *http.Request) {
	var d auxiliar.Pagina

	// Carrega title do site
	d.TituloSite = config.TituloSite

	d.NomeTela = "Gerenciar Procedimento de Atendimento"

	d.LogoMarca = "logo2Id6.png"

	d.LinkRetorno = "/carregar-menu-atendimento"
	// Carrega o HTML
	auxiliar.ExecutarTemplate(w, "gerenciar-procedimento-atendimento.html", d)
}

func ProcedimentoCarregarTabela(w http.ResponseWriter, r *http.Request) {
	idFranqueado := mux.Vars(r)["idFranqueado"]

	url := fmt.Sprintf("%s/procedimento-carregar-tabela/%s", config.ApiUrl, idFranqueado)
	resp, erro := seguranca.RequisiacaoAutenticada(r, http.MethodGet, url, nil)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	if resp.StatusCode >= 400 {
		auxiliar.TratarStatusCodeDeErro(w, resp)
		return
	}

	corpo, erro := io.ReadAll(resp.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	auxiliar.RespostaAPP(w, corpo)
}

func ProcedimentoHabilitar(w http.ResponseWriter, r *http.Request) {
	idTecnico := mux.Vars(r)["id"]
	status := mux.Vars(r)["status"]

	url := fmt.Sprintf(
		"%s/procedimento-habilitar/%s/%s",
		config.ApiUrl, idTecnico, status,
	)

	resp, erro := seguranca.RequisiacaoAutenticada(r, http.MethodGet, url, nil)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	if resp.StatusCode >= 400 {
		auxiliar.TratarStatusCodeDeErro(w, resp)
		return
	}

	corpo, erro := io.ReadAll(resp.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)

	}

	auxiliar.RespostaAPP(w, corpo)
}

func ProcedimentoInserir(w http.ResponseWriter, r *http.Request) {
	corpo, erro := io.ReadAll(r.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	url := fmt.Sprintf("%s/procedimento-incluir", config.ApiUrl)

	resp, erro := seguranca.RequisiacaoAutenticada(
		r, http.MethodPost, url, bytes.NewBuffer(corpo),
	)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	if resp.StatusCode >= 400 {
		auxiliar.TratarStatusCodeDeErro(w, resp)
		return
	}

	corpo, erro = io.ReadAll(resp.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)

	}

	auxiliar.RespostaAPP(w, corpo)
}

func ProcedimentoBuscar(w http.ResponseWriter, r *http.Request) {
	idTecnico := mux.Vars(r)["id"]

	url := fmt.Sprintf("%s/procedimento-buscar/%s", config.ApiUrl, idTecnico)

	resp, erro := seguranca.RequisiacaoAutenticada(r, http.MethodGet, url, nil)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	if resp.StatusCode >= 400 {
		auxiliar.TratarStatusCodeDeErro(w, resp)
		return
	}

	corpo, erro := io.ReadAll(resp.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)

	}

	auxiliar.RespostaAPP(w, corpo)
}

func ProcedimentoAlterar(w http.ResponseWriter, r *http.Request) {
	corpo, erro := io.ReadAll(r.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	url := fmt.Sprintf("%s/procedimento-alterar", config.ApiUrl)
	fmt.Println(url)
	resp, erro := seguranca.RequisiacaoAutenticada(
		r, http.MethodPut, url, bytes.NewBuffer(corpo),
	)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	if resp.StatusCode >= 400 {
		auxiliar.TratarStatusCodeDeErro(w, resp)
		return
	}

	corpo, erro = io.ReadAll(resp.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)

	}

	auxiliar.RespostaAPP(w, corpo)
}

func ProcedimentoDeletar(w http.ResponseWriter, r *http.Request) {
	corpo, erro := io.ReadAll(r.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	url := fmt.Sprintf("%s/procedimento-deletar", config.ApiUrl)
	fmt.Println(url)
	resp, erro := seguranca.RequisiacaoAutenticada(
		r, http.MethodDelete, url, bytes.NewBuffer(corpo),
	)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)
		return
	}

	if resp.StatusCode >= 400 {
		auxiliar.TratarStatusCodeDeErro(w, resp)
		return
	}

	corpo, erro = io.ReadAll(resp.Body)
	if erro != nil {
		auxiliar.RespostaErro(w, http.StatusBadRequest, erro)

	}

	auxiliar.RespostaAPP(w, corpo)
}
